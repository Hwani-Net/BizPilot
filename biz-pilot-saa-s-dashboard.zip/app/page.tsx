"use client"

import  from "../components/settings/settings-content"

export default function SyntheticV0PageForDeployment() {
  return < />
}